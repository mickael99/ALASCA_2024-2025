package fr.sorbonne_u.components.equipments.smartLighting.mil.events;

import fr.sorbonne_u.devs_simulation.models.events.EventI;

public interface SmartLightingEventI extends EventI {
}
// -----------------------------------------------------------------------------
