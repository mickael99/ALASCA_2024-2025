package fr.sorbonne_u.components.equipments.hem.mil;

public interface HEM_ReportI {
	public String printout(String indent);
}
