package fr.sorbonne_u.components.equipments.toaster.mil.events;

import fr.sorbonne_u.devs_simulation.models.events.EventI;

public interface ToasterEventI extends EventI {
}
