package fr.sorbonne_u.components.equipments.fridge.mil.events;

import fr.sorbonne_u.devs_simulation.models.events.EventI;

public interface FridgeEventI extends EventI {

}
